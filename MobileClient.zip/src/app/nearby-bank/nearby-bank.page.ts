import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nearby-bank',
  templateUrl: './nearby-bank.page.html',
  styleUrls: ['./nearby-bank.page.scss'],
})
export class NearbyBankPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
