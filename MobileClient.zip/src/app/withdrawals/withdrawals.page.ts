import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdrawals',
  templateUrl: './withdrawals.page.html',
  styleUrls: ['./withdrawals.page.scss'],
})
export class WithdrawalsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
