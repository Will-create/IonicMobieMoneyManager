import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan-info',
  templateUrl: './loan-info.page.html',
  styleUrls: ['./loan-info.page.scss'],
})
export class LoanInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
