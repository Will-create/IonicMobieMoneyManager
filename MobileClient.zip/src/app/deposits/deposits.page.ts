import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deposits',
  templateUrl: './deposits.page.html',
  styleUrls: ['./deposits.page.scss'],
})
export class DepositsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
