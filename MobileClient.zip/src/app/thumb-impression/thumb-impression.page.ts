import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thumb-impression',
  templateUrl: './thumb-impression.page.html',
  styleUrls: ['./thumb-impression.page.scss'],
})
export class ThumbImpressionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
