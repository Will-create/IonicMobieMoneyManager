import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-longforms',
  templateUrl: './longforms.page.html',
  styleUrls: ['./longforms.page.scss'],
})
export class LongformsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
